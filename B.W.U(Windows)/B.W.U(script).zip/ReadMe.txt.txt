 �,����`Better Windows Ulco`����,�

	Version actuel: 	1.a
	Auter Origniel: 	NaoKi
	inspirer par:		Ulco Enhancer
	Derni�re Modif:		11/07/2015

Information:
	Les sessions sur windows sont g�n�ralement largement brid�, ce script dois permettre d'am�liorer la situation via quelques modifications
Toutesfois sachez que ces modifications risquent de ne pas �tre tol�rer par votre admin r�seaux et donc en utilisant le script vous vous expos� a des
sanction dont vous �tes les seul responsable, en aucun cas nous ne serons �tre tenu pour responsable. 
a but instructif avant tout.

Ce que fais le script: 
	- Ajoute un fond d'�cran.
	- Red�mmarage de l'explorateur Windows.
	- Changement d'un registre temporaire.

Envie de personaliser l'image:
	L'image dois �tre au format bmp la taille importe peu.


